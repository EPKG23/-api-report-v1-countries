Baixando as dependências do projeto
npm install

Rodando o projeto
npm run dev

obs: não consegui executar o gráfico por alguns problemas de dependências mas o código está aí para qualquer dúvida.
